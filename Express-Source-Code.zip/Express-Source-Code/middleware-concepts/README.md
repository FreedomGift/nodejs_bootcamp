## 🧑‍🏫 Project: **Express Middleware Practice**

This project helps beginners **experience** the full flow of middleware inside an Express app — all within a single file. We'll use **in-memory data** (simple JavaScript array)

---

## 📘 Project Overview

We’re building a small app where users can:

- View all users
- Admins can access a protected dashboard

🧪 And we’ll use this project to explore:

✅ Built-in middleware
✅ Third-party middleware
✅ Custom middleware
✅ Application-level middleware

---

## 🧠 In-Memory "Database"

```js
const users = [
  { id: 1, username: "alice", role: "user" },
  { id: 2, username: "bob", role: "admin" },
];
```
