# 🛍️ Practice Project: **Mini Express Store**

**Goal:** Build a tiny store website using Express.js routes.
You'll use `GET` and `POST` methods, understand `req` and `res`, and run a Node server.

---

## 🔍 Project Overview — Think & Code

> 💬 What are we building?

We're building a **Mini Store API** with Express where:

- A user can visit the homepage
- See available products
- Learn about the store
- Contact the store
- Sign up with a `POST` request
