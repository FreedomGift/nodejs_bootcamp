## 🔥 Project Title:Express Multi-Page Website

## 🎯 Project Goal

Build a **multi-page website** using Express.js that demonstrates how to:

- Serve **HTML, CSS, and image files** statically using Express middleware
- Create **routes for each page** using `app.get()`
- Apply clean URL structure (`/about` instead of `/about.html`)
- Use a shared **navbar** across all pages
- Organize project folders like a real web project

No need for template engines or databases. Just pure HTML, CSS, images, and Express routing!
|

Each page:

✅ Loads with its own image
✅ Uses a consistent CSS file
✅ Shares a clean **navbar** with links to other pages
✅ Uses Express to handle routing and serve files
