const express = require("express");

//!Initialize express
const app = express();

//---ROUTE CHAINING---
//!Route for /books
app
  .route("/books")
  .get((req, res) => {
    res.send("Get all books");
  })
  .post((req, res) => {
    res.send("Post a new books");
  })
  .delete((req, res) => {
    res.send("DELETE all books");
  });

//!Route for /books/:id
app
  .route("/books/:id")
  .get((req, res) => {
    res.send(`Get a single book-${req.params.id}`);
  })
  .put((req, res) => {
    res.send("PUT: Update a book");
  })
  .delete((req, res) => {
    res.send("DELETE all books");
  });
//!Start the server
app.listen(3000, () => {
  console.log("Server is up and running");
});
