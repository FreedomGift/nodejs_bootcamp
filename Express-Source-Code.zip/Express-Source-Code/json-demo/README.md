## 🧪 Project Name: **Book Manager API**

Think of this like a super basic backend for a library or bookstore. 📚

You’ll be able to:

- View all books
- Add a new book
- Get a specific book by ID
- Update a book by ID
- Delete a book by ID
